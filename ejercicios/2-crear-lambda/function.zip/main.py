def dynamodb_events(event, context):
    print("DynamoDB event received:")
    print(event)
